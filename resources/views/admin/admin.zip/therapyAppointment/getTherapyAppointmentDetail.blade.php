<div class="ribbon-content mt-4 text-muted">
    <p>Name : {{ $name }}</p>
    <p>Age: {{ $age }}</p>
    <p>Email Address: {{ $email }}</p>
</div>
